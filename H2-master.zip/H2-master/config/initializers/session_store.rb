# Be sure to restart your server when you modify this file.

H2::Application.config.session_store :cookie_store, key: '_h2_session'
